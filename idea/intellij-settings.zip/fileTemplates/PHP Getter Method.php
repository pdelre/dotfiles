#set($SNAKE_NAME = ${GET_OR_IS}+"_"+${NAME.replaceAll("([a-z])([A-Z])", "$1_$2").toLowerCase()})

/**
 * @return ${TYPE_HINT}
 */
public ${STATIC} function ${SNAKE_NAME}()
{
#if (${STATIC} == "static")
    return self::$${FIELD_NAME};
#else
    return $this->${FIELD_NAME};
#end
}
