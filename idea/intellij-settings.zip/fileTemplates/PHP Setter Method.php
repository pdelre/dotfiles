#set($SNAKE_NAME = "set_"+${NAME.replaceAll("([a-z])([A-Z])", "$1_$2").toLowerCase()})

/**
 * @param ${TYPE_HINT} $${PARAM_NAME}
 */
public ${STATIC} function ${SNAKE_NAME}($${PARAM_NAME})
{
#if (${STATIC} == "static")
    self::$${FIELD_NAME} = $${PARAM_NAME};
#else
    $this->${FIELD_NAME} = $${PARAM_NAME};
#end
}
