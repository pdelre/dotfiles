<?php

#parse("PHP File Header.php")

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use WF\Tests\PHPUnit\Wayfair_Test_Wrapper;

class ${NAME} extends Wayfair_Test_Wrapper {

}
