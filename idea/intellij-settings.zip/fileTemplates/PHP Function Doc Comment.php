/**
${PARAM_DOC}
#if ($THROWS_DOC != "")${THROWS_DOC}*
#end
* @return ${TYPE_HINT}
*/
